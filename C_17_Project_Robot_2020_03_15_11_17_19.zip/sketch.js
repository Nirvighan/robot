
function setup() {
  
  //create the background
  createCanvas(500, 600);
  
}

function draw() {
  
  //give colour to the background
  background("green");
  
  
  //fill colour in robot body
  fill("pink");
  
  //create the head
  ellipse(180,160,70,70);
  
  //create the rest of the body structure
  rect(150,240,60,100);
  
  
  
  
  //fill colour in tyre
  fill("grey");
  
  //create the tyre
  ellipse(180,350,50,50);
  
  
  
  //fill colour in eyes
  fill("white");
  
  //create the eyes
  ellipse(190,145,20,20);
  
  
  
  //fill colur in nose and on the top of antenna
  fill("red");
  
  //create the nose
  rect(210,160,25,5);
  
  //create the top of antenna
  ellipse(120,120,20,20);
  
  
  //create the neck
  line(180,195,180,240);
  
  //create the mouth
  line(120,120,155,145);
  
  //create the antenna
  line(180,180,200,180);
  
  
}